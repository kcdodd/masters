#ifndef RADIALSOLVER_HPP_INCLUDED
#define RADIALSOLVER_HPP_INCLUDED

#include "VectorN.hpp"
#include "dynarray.hpp"

struct bd_intersect{
    // bd: outer=0, inner=1, top=2
    int bd_1;
    int bd_2;
    int bd_3;

    unsigned int n_1;
    unsigned int n_2;
    unsigned int n_3;

    double fraction_1;
    double fraction_2;
    double fraction_3;
};

template<
    unsigned int numr,
    unsigned int numz,
    unsigned int numr_bd,
    unsigned int numz_bd,
    unsigned int numv>
class RadialSolver
{

private:
    static const unsigned int num_bd = numr_bd + 2*numz_bd;
    static const unsigned int total_numv = 2*numv-1;

    double mMinr; ///< Inner radiusŔ
    double mMaxr; ///< Outer radius
    double mMaxz; ///< 1/2 height of chamber. Center is z=0.

    double mMass; ///< mass of single neutral atom

    double mT0; ///< temperature of neutrals
    double mVth;

    double mLi[numr]; ///< ionization loss rate in 1/s

    dynarray<double> mM;
    dynarray<double> mN;

    double mZ[numz]; ///< Z coordinates if non-equal increments

    double mSolutionN[numr][numz];
    double mSolutionVr[numr][numz];
    double mSolutionVz[numr][numz];

    double mSolN_BD_top[numr_bd];
    double mSolN_BD_outer[numz_bd];
    double mSolN_BD_inner[numz_bd];

    double mSolN_BD_top_tmp[numr_bd];
    double mSolN_BD_outer_tmp[numz_bd];
    double mSolN_BD_inner_tmp[numz_bd];

    bool mBD_matrix_compiled;
    double mBD_matrix[num_bd][num_bd];

    double mDr_bd;
    double mDz_bd;

    double mDr;
    double mDz;

    double mDtheta;
    double mDphi;

public:

    /**
        Constructor for solver.

        @param minr Inner radius of chamber
        @param maxr Outer radius of chamber
        @param maxz 1/2 of chamber height: z=0 is in center of chamber
        @param mass Neutral atom mass
        @param T0 Thermal temperature of neutrals
        @param Li Ionization loss rate of neutral atoms in units of 1/s as a function of radius, starting at inner radius
                and ending at outer radius.
    */
    RadialSolver(
        double minr,
        double maxr,
        double maxz,
        double mass,
        double T0,
        const double (&Li)[numr],
        const std::string& M_file,
        const std::string& N_file);

    double solutionN(unsigned int nr, unsigned int nz);

    double solutionVr(unsigned int nr, unsigned int nz);

    double solutionVz(unsigned int nr, unsigned int nz);

    double boundaryN(unsigned int n, unsigned int bd);

    /**

    */
    double avg_ion_rate();

    double avg_n();


    void solve_bd(
        double precision,
        unsigned int max_iterations,
        bool multithread);

    // bd: outer=0, inner=1, top=2
    void solve_bd(
        unsigned int n,
        unsigned int bd);

    // bd: outer=0, inner=1, top=2
    void compile_bd(
        unsigned int n,
        unsigned int bd);

    void solve(bool multithread);

    void solve(
        unsigned int nr,
        unsigned int nz);

    void integrate(
        double r,
        double z,
        double theta,
        double phi,
        double& nM,
        double& nN,
        bd_intersect& intersect);

    unsigned int bd_index(
        unsigned int n,
        unsigned int bd);

    double neTe_profile_function(double r, double rp, double gamma);
};

#endif // ARIRADIALSOLVER_HPP_INCLUDED
